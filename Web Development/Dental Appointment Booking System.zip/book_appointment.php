<?php
session_start();
require_once('db_connect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $userId = $_POST['user_id'];
    $appointmentId = $_POST['appointment_id'];
    $appointmentDate = $_POST['appointment_date'];
    $appointmentTime = $_POST['appointment_time'];
    $reason = $_POST['reason'];
    $status = 'pending'; // Ensure status is set correctly

    // Use DateTime to parse and format the date and time separately
    $date = DateTime::createFromFormat('m/d/Y', $appointmentDate); // Adjust the format as per your input
    $formattedDate = $date->format('Y-m-d');

    $time = DateTime::createFromFormat('H:i A', $appointmentTime); // Adjust the format as per your input
    $formattedTime = $time->format('H:i');

    // Prepare the SQL statement
    $sql = "INSERT INTO booking (appointment_id, user_id, appointment_date, appointment_time, reason, status) 
            VALUES ('$appointmentId', '$userId', '$formattedDate', '$formattedTime', '$reason', '$status')";

    if (mysqli_query($conn, $sql)) {
        // Show JavaScript alert and redirect to homepage
        echo "<script>
                alert('Your appointment has been successfully booked. Please wait for acceptance.');
                window.location.href = 'index.php'; // Adjust the URL to your homepage
              </script>";
    } else {
        // Display error message if insertion fails
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    // Close the database connection
    mysqli_close($conn);
} else {
    // Redirect back to appointment page if accessed directly
    header('Location: appointment.php');
    exit();
}
?>






