<?php
    session_start();
    include ('header.php');
    include ('db_connect.php');

    if (!isset($_SESSION['customer'])) {
        header('location:login.php');
        exit;
    }

    $email = $_SESSION['customer'];
   
    $sql = "SELECT * FROM user_profile WHERE email='$email'";
    $result = mysqli_query($conn, $sql);
    $user = mysqli_fetch_assoc($result);
?>

<style>
    body {
        margin: 0;
        font: 0 16px/18px 'Open Sans', sans-serif;
        background-color: #f0faff;
    }

    .login-wrap {
        width: 100%;
        margin: auto;
        margin-top: 50px;
        max-width: 900px; 
        display: flex;
        justify-content: center; 
    }

    .login-html {
        width: 100%;
        padding: 20px; 
        display: flex; 
    }

    .user-info {
        width: 50%; 
        padding: 20px; 
        background-color: #ffffff; 
        border-radius: 25px;
        box-shadow: 0 12px 15px 0 rgba(0, 0, 0, .24), 0 17px 50px 0 rgba(0, 0, 0, .19);
    }

    .user-info img {
        width: 150px; 
        height: 150px;
        border-radius: 50%; 
        object-fit: cover;
    }

    .login-form {
        width: 50%;
        padding: 20px;
        background-color: #ffffff; 
        border-radius: 25px;
        box-shadow: 0 12px 15px 0 rgba(0, 0, 0, .24), 0 17px 50px 0 rgba(0, 0, 0, .19);
    }

    .tab {
        font-size: 30px;
        padding-bottom: 20px;
        border-bottom: 2px solid transparent;
        color: #1161ee;
    }

    .tab:hover {
        color: #0a4bc2;
    }

    .group {
        margin-bottom: 15px;
    }

    .label {
        color: #1161ee; 
        font-size: 14px;
    }

    .input {
        border: none;
        padding: 15px 20px;
        border-radius: 25px;
        color: #1161ee; 
        background-color: #f0faff; 
        width: calc(100% - 40px); 
    }

    .input:focus {
        outline: none;
        box-shadow: 0 0 10px #1161ee; 
    }

    .button {
        border: none;
        padding: 15px 20px;
        border-radius: 25px;
        color: #fff;
        background-color: #1161ee; 
        cursor: pointer;
    }

    .button:hover {
        background-color: #0a4bc2;
    }

    .hr {
        height: 2px;
        margin: 30px 0; 
        background: rgba(17, 97, 238, 0.2); 
    }

    .foot-lnk a:link,
    .foot-lnk a:visited {
        color: #1161ee;
        text-decoration: none;
    }

    .foot-lnk a:hover {
        color: #0a4bc2; 
    }

    .foot-lnk a:active {
        color: red; 
    }
</style>

<html>
<body>
<div class="login-wrap">
    <div class="login-html">
        <div class="user-info">
            <label class="tab">User Information</label>
            <div class="group">
                <p><strong>User ID:</strong> <?php echo $user['user_id']; ?></p>
                <p><strong>First Name:</strong> <?php echo $user['user_first_name']; ?></p>
                <p><strong>Last Name:</strong> <?php echo $user['user_last_name']; ?></p>
                <p><strong>Email:</strong> <?php echo $user['email']; ?></p>
            </div>
            <form method="post" action="update_photo_process.php" enctype="multipart/form-data">
                <div class="group">
                    <label for="photo" class="label">Change Photo</label>
                    <input type="file" id="photo" name="photo" accept="image/*" class="input">
                </div>
                <div class="group">
                    <input type="submit" class="button" value="Upload Photo">
                </div>
            </form>
            <div class="group">
                <img src="<?php echo $user['photo'] ? $user['photo'] : 'img/profile-icon.jpeg'; ?>" alt="Profile Photo">
            </div>
        </div>
        <div class="login-form">
            <label class="tab">Update Profile</label>
            <form method="post" action="update_profile_process.php">
                <div class="group">
                    <label for="user_first_name" class="label">First Name</label>
                    <input id="user_first_name" name="user_first_name" type="text" class="input" value="<?php echo $user['user_first_name']; ?>" required>
                </div>
                <div class="group">
                    <label for="user_last_name" class="label">Last Name</label>
                    <input id="user_last_name" name="user_last_name" type="text" class="input" value="<?php echo $user['user_last_name']; ?>" required>
                </div>
                <div class="group">
                    <label for="email" class="label">E-mail Address</label>
                    <input id="email" name="email" type="text" class="input" value="<?php echo $user['email']; ?>" readonly>
                </div>
                <div class="group">
                    <label for="pass" class="label">Password</label>
                    <input id="pass" name="password" type="password" class="input" value="<?php echo $user['user_password']; ?>" required>
                </div>
                <div class="group">
                    <label for="user_ic" class="label">IC Number</label>
                    <input id="user_ic" name="user_ic" type="text" class="input" value="<?php echo $user['user_ic']; ?>" required>
                </div>
                <div class="group">
                    <label for="gender" class="label">Gender</label>
                    <input id="gender" name="gender" type="text" class="input" value="<?php echo $user['gender']; ?>">
                </div>
                <div class="group">
                    <label for="age" class="label">Age</label>
                    <input id="age" name="age" type="number" class="input" value="<?php echo $user['age']; ?>">
                </div>
                <div class="group">
                    <label for="phone_no" class="label">Phone Number</label>
                    <input id="phone_no" name="phone_no" type="text" class="input" value="<?php echo $user['phone_no']; ?>">
                </div>
                <div class="group">
                    <input type="submit" class="button" value="Update Profile">
                </div>
                <div class="hr"></div>
                <div class="foot-lnk">
                    <a href="index.php">Back to Home</a>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="lib/wow/wow.min.js"></script>
<script src="lib/easing/easing.min.js"></script>
<script src="lib/waypoints/waypoints.min.js"></script>
<script src="lib/counterup/counterup.min.js"></script>
<script src="lib/owlcarousel/owl.carousel.min.js"></script>
<script src="lib/tempusdominus/js/moment.min.js"></script>
<script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
<script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

<!-- Template Javascript -->
<script src="js/main.js"></script>

</body>
<?php
    include 'footer.php';
?>
</html>
