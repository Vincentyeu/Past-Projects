<?php
session_start();
include('db_connect.php');

if (!isset($_SESSION['customer'])) {
    header('Location: login.php');
    exit;
}

$email = $_SESSION['customer'];


// Check if a file was uploaded
if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
    $fileTmpPath = $_FILES['photo']['tmp_name'];
    $fileName = $_FILES['photo']['name'];
    $fileSize = $_FILES['photo']['size'];
    $fileType = $_FILES['photo']['type'];
    $fileNameCmps = explode(".", $fileName);
    $fileExtension = strtolower(end($fileNameCmps));

    // Valid image file extensions
    $allowedExtensions = array('jpg', 'jpeg', 'png');

    // Check if uploaded file is an image
    if (in_array($fileExtension, $allowedExtensions)) {
        // Directory where the uploaded file will be moved
        $uploadDir = 'uploads/';
        
        // Create directory if it doesn't exist
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true); // Adjust permissions as needed
        }

        $destPath = $uploadDir . $fileName;

        // Move uploaded file to specified directory
        if (move_uploaded_file($fileTmpPath, $destPath)) {
            // Update photo field in database
            $sqlUpdate = "UPDATE user_profile SET photo = '$destPath' WHERE email = '$email'";
            $resultUpdate = mysqli_query($conn, $sqlUpdate);

            if ($resultUpdate) {
                // Redirect back to profile page after successful update
                header('Location: update_profile.php');
                exit;
            } else {
                echo "Error updating photo in database.";
            }
        } else {
            echo "Error moving uploaded file to destination.";
        }
    } else {
        echo "Invalid file type. Only JPG, JPEG, and PNG files are allowed.";
    }
} else {
    echo "No file uploaded or file upload error occurred.";
}
?>
