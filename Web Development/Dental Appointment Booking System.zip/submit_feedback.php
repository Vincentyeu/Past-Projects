<?php
session_start();
require_once 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $feedbackId = $_POST['feedback_id'];
    $userId = $_POST['user_id'];
    $dentistId = $_POST['dentist_id'];
    $userRating = $_POST['user_rating'];
    $userComment = $_POST['user_comment'];

    $sql = "INSERT INTO feedback (feedback_id, user_id, dentist_id, user_rating, user_comment) VALUES ('$feedbackId', '$userId', '$dentistId', '$userRating', '$userComment')";

    if (mysqli_query($conn, $sql)) {
        echo "<script>
            alert('Thank you for your feedback!');
            window.location.href='index.php';
        </script>";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    mysqli_close($conn);
} else {
    header('Location: feedback.php');
    exit();
}
?>
