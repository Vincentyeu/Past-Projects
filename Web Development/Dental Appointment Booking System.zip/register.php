<?php
	session_start();
	require_once('db_connect.php');
?>

<style>
    body{
	margin: 0;;
	/*color:#6a6f8c;
	background:#c8c8c8;*/
    background-image: url("../TSE_Dental Appointment Booking/img/header1.jpg");
    background-repeat:no-repeat;
    background-attachment: fixed;
    background-position: center;
    background-size:cover;
	font:0 16px/18px 'Open Sans',sans-serif;
}
*,:after,:before{box-sizing:border-box}
.clearfix:after,.clearfix:before{content:'';display:table}
.clearfix:after{clear:both;display:block}
a{color:inherit;text-decoration:none}

.login-wrap{
	width:100%;
	margin: auto;
    margin-top: 50px;
	max-width:626px;
	min-height:770px;
	position:relative;
    /*background-image: url("../img/header1.jpg") center no-repeat;
	 background:url(https://raw.githubusercontent.com/khadkamhn/day-01-login-form/master/img/bg.jpg) no-repeat center; */
    background: white;
    border-radius:25px;
	/*box-shadow:0 12px 15px 0 rgba(0,0,0,.24),0 17px 50px 0 rgba(0,0,0,.19); */
}

.login-html{
	width:100%;
	height:100%;
	position:absolute;
	padding: 50px 70px 50px 70px;
	/*background:rgba(40,57,101,.9);*/
}

.login-html .sign-in-htm,
.login-html .sign-up-htm{
	top:0;
	left:0;
	right:0;
	bottom:0;
	position:absolute;
	transform:rotateY(180deg);
	backface-visibility:hidden;
	transition:all .4s linear;
}
.login-html .sign-in,
.login-html .sign-up,
.login-form .group .check{
	display:none;
}
.login-html .tab,
.login-form .group .label,
.login-form .group .button{
	text-transform:uppercase;
    color:black;
	font-weight:bold;
}
.login-html .tab{
	font-size:30px;
	/*margin-right:15px;*/
	padding-bottom:20px;
	margin:auto;/*0 15px 10px 0 */
	display:inline-block;
	border-bottom:2px solid transparent;
}
.login-html .sign-in:checked + .tab,
.login-html .sign-up:checked + .tab{
	/*color:#fff;
    border-color:#1161ee; */
    color:black;
	
}
.login-form{
	min-height:345px;
	position:relative;
	perspective:1000px;
	transform-style:preserve-3d;
}
.login-form .group{
	margin-bottom:15px;
}
.login-form .group .label,
/*.login-form .group .input,*/
.login-form .group .button{
	width:100%;
	margin-bottom:2px;
	/*color:#fff;*/
	display:block;
}
.login-form .group .input{
    width:100%;
    border:none;
	padding:15px 20px;
	border-radius:25px;
    color:black;
    background:Aliceblue;
	/*background:rgba(255,255,255,.1);*/
}
.login-form .group .button{
	border:none;
	padding:15px 20px;
	border-radius:25px;
    color:white;
    background-color:lightskyblue;
	/*background:rgba(255,255,255,.1);*/
}
.login-form .group input[type="password"]{
	text-security:circle;
	-webkit-text-security:circle;
}
.login-form .group .label{
	color:black;/*#aaa */
	font-size:12px;
}
.login-form .group .button{
	background:#1161ee;
	margin-top:70px;
}

.login-form .group .button:hover{
	background:black;
}

.login-form .group label .icon{
	width:15px;
	height:15px;
	border-radius:2px;
	position:relative;
	display:inline-block;
	background-color:rgba(255,255,255,.1);
}
.login-form .group label .icon:before,
.login-form .group label .icon:after{
	content:'';
	width:10px;
	height:2px;
	background:#fff;
	position:absolute;
	transition:all .2s ease-in-out 0s;
}
.login-form .group label .icon:before{
	left:3px;
	width:5px;
	bottom:6px;
	transform:scale(0) rotate(0);
}
.login-form .group label .icon:after{
	top:6px;
	right:0;
	transform:scale(0) rotate(0);
}
.login-form .group .check:checked + label{
	color:#fff;
}
.login-form .group .check:checked + label .icon{
	background:#1161ee;
}
.login-form .group .check:checked + label .icon:before{
	transform:scale(1) rotate(45deg);
}
.login-form .group .check:checked + label .icon:after{
	transform:scale(1) rotate(-45deg);
}
.login-html .sign-in:checked + .tab + .sign-up + .tab + .login-form .sign-in-htm{
	transform:rotate(0);
}
.login-html .sign-up:checked + .tab + .login-form .sign-up-htm{
	transform:rotate(0);
}

.hr{
	height:2px;
	margin:60px 0 50px 0;
	background:rgba(255,255,255,.2);
}

.foot-lnk{
	text-align:left;
	margin-top:0;
}

.foot-lnk a:link{
	color:grey;
}

.foot-lnk a:hover{
	color:deepskyblue;
}

.foot-lnk a:active{
	color:red;
}

</style>

<html>

<body>
    <div class="login-wrap">
	    <div class="login-html">    
         <!--<input id="tab-1" type="radio" name="tab" class="sign-in" ><label for="tab-1" class="tab">Sign In</label> -->
		<input id="tab-2" type="radio" name="tab" class="sign-up"checked><label for="tab-2" class="tab">Create An Account</label>
            <div class="login-form">
	    		<form class="sign-up-htm" method="post">
					<div>
                        <?php
                            //session_start();
                            //require_once('connectdb.php');
                            if(isset($_POST) &!empty($_POST)){
                                $fname=$_POST['firstname'];
                                $lname=$_POST['lastname'];
                                $email=$_POST['email'];
								$uic=$_POST['icnum'];
                                $pass=$_POST['pass'];
                                $cpass=$_POST['cpass'];
                                $select = mysqli_query($conn, "SELECT * FROM `user_profile` WHERE email='$email'AND user_password='$pass'"); //
                
                            if(mysqli_num_rows($select) > 0)
                            {
                                $message[] = 'User already exist';
                            }
                            else
                            {
                                if($pass != $cpass)
                                {
                                    $message[] = 'Confirm password not matched !';
                                }
                                else
                                {	$query = mysqli_query($conn, "SELECT MAX(SUBSTRING(user_id, 2) + 0) AS max_id FROM user_profile");
									$row = mysqli_fetch_assoc($query);
									$max_id = $row['max_id'];
									$next_id = $max_id + 1;
									$user_id = 'U' . $next_id;

                                    $insert = mysqli_query($conn, "INSERT INTO `user_profile`(user_id, email, user_first_name, user_last_name, user_password, user_ic) VALUES('$user_id', '$email','$fname','$lname', '$pass', '$uic')");
                
                                    if($insert)
                                    {
                                        $success[] = 'Register Successfully !';
                                    }
									else
									{
										$message[] = 'Register Failed !';
									}
                                    
                                }
                                
                            }
                        }
                        ?>
                    </div>

                    <div>
                    <?php
    				    if(isset($message))
    				    {
        				    foreach($message as $message)
        				    {
                                ?><div class="alert alert-danger"><?php echo $message ?></div><?php
        				    }
    				    }
    					else if(isset($success))
    					{
    						foreach($success as $success)
        				    {
                                ?><div class="alert alert-success"><?php echo $success ?></div><?php
        				    }
    					}
    					else if(isset($message))
    					{
                            ?><div id="message">
                           <h3>Password must contain the following:</h3>
                           <p id="letter" class="invalid">A <b>lowercase</b> letter</p>
                           <p id="capital" class="invalid">A <b>capital (uppercase)</b> letter</p>
                           <p id="number" class="invalid">A <b>number</b></p>
                           <p id="length" class="invalid">Minimum <b>8 characters</b></p>
                           </div><?php
    					}   
                        ?>
                        </div>
					<div class="row">
	    			<div class="group col-md-6">
	    				<label for="user" class="label">First name</label>
	    				<input id="firstname" name="firstname" type="text" class="input" placeholder="First" title="Enter your first name" style="background-color:Aliceblue" required>
	    			</div>
                    <div class="group col-md-6">
	    				<label for="user" class="label">Last name</label>
	    				<input id="lastname" name="lastname" type="text" class="input" placeholder="Last" title="Enter your last name" style="background-color:Aliceblue" required>
	    			</div>
					</div>
                    <div class="group">
                        <label for="pass" class="label">Email Address</label>
                        <input id="email" name="email" type="email" class="input" data-type="email" placeholder="Email" title="Enter your email address" style="background-color:Aliceblue" required>
                    </div>
					<div class="group">
                        <label for="pass" class="label">Indentity Card Number</label>
                        <input id="icnum" name="icnum" type="text" class="input" data-type="number" placeholder="123456121234" pattern="[0-9]{12}" title="Enter without -" required>
                    </div>
	    			<div class="group">
	    				<label for="pass" class="label">Password</label>
	    				<input id="pass" name="pass" type="password" class="input" data-type="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" onclick="ShowRequirement()" title="Enter password" required>
	    			</div>
	    			<div class="group">
	    				<label for="pass" class="label">Confirm Password</label>
	    				<input id="cpass" name="cpass" type="password" class="input" data-type="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" onclick="ShowRequirement()" title="Enter password" required>
	    			</div>
					<div class="registerform" id="requirement" style="display:none">
						<b> Password must include at least 8 numbers,1 Uppercase and 1 Lowercase </b>
					</div>
					<div class="group">
						<button type="submit" class="button" value="Sign Up">Sign Up</button>
					</div>
					<div class="foot-lnk" >
						<a href="login.php"> Already have an account?</a>
					</div>
	    			<!--<div class="hr"></div>-->
                </form>
                    
	    	</div> 
    	</div>
    </div>

<!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>

	<script>
var myInput = document.getElementById("psw");
var letter = document.getElementById("letter");
var capital = document.getElementById("capital");
var number = document.getElementById("number");
var length = document.getElementById("length");

function ShowRequirement()
		{
            document.getElementById('requirement').style.display = "block";
        }

// When the user clicks on the password field, show the message box
myInput.onfocus = function() {
  document.getElementById("message").style.display = "block";
}

// When the user clicks outside of the password field, hide the message box
myInput.onblur = function() {
  document.getElementById("message").style.display = "none";
}

// When the user starts to type something inside the password field
myInput.onkeyup = function() {
  // Validate lowercase letters
  var lowerCaseLetters = /[a-z]/g;
  if(myInput.value.match(lowerCaseLetters)) {  
    letter.classList.remove("invalid");
    letter.classList.add("valid");
  } else {
    letter.classList.remove("valid");
    letter.classList.add("invalid");
  }
  
  // Validate capital letters
  var upperCaseLetters = /[A-Z]/g;
  if(myInput.value.match(upperCaseLetters)) {  
    capital.classList.remove("invalid");
    capital.classList.add("valid");
  } else {
    capital.classList.remove("valid");
    capital.classList.add("invalid");
  }

  // Validate numbers
  var numbers = /[0-9]/g;
  if(myInput.value.match(numbers)) {  
    number.classList.remove("invalid");
    number.classList.add("valid");
  } else {
    number.classList.remove("valid");
    number.classList.add("invalid");
  }
  
  // Validate length
  if(myInput.value.length >= 8) {
    length.classList.remove("invalid");
    length.classList.add("valid");
  } else {
    length.classList.remove("valid");
    length.classList.add("invalid");
  }
}
</script>


</body>



<?php
    include 'footer.php'
?>

</html>
