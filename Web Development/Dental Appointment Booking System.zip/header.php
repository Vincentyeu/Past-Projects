<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Your Clinic Name - Clinic Website Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="your, keywords, here">
    <meta name="description" content="Your website description here">

    <!-- Favicon -->
    <link rel="icon" href="img/favicon.ico">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500&family=Roboto:wght@500;700;900&display=swap"
        rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css">

    <!-- Libraries Stylesheet -->
    <link rel="stylesheet" href="lib/animate/animate.min.css">
    <link rel="stylesheet" href="lib/owlcarousel/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css">

    <!-- Customized Bootstrap Stylesheet -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Template Stylesheet -->
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
<!-- Navbar Start -->
<nav class="navbar navbar-expand-lg bg-white navbar-light sticky-top p-0 wow fadeIn" data-wow-delay="0.1s">
    <div class="container-fluid">
        <a href="index.php" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
            <h1 class="m-0"><i class="far fa-hospital me-3" style="color: deepskyblue;"></i>Dental Group 4</h1>
        </a>
        <button class="navbar-toggler me-4" type="button" data-bs-toggle="collapse"
            data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false"
            aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <ul class="navbar-nav ms-auto p-4 p-lg-0">
                <li class="nav-item">
                    <a href="index.php" class="nav-link active">Home</a>
                </li>
                <li class="nav-item">
                    <a href="about.php" class="nav-link">About</a>
                </li>
                <li class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" id="pagesDropdown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">Pages</a>
                    <ul class="dropdown-menu rounded-0 rounded-bottom m-0" aria-labelledby="pagesDropdown">
                        <li><a href="appointment.php" class="dropdown-item">Appointment</a></li>
                        <li><a href="appointment_history.php" class="dropdown-item">Appointment History</a></li>
						<li><a href="search_dentist.php" class="dropdown-item">Dentist list</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a href="feedback.php" class="nav-link">Feedback</a>
                </li>
                <li class="nav-item">
                    <a href="update_profile.php" class="nav-link">Profile</a>
                </li>
                <li class="nav-item">
                    <a href="login.php" class="nav-link">Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<!-- Navbar End -->

</body>

</html>
