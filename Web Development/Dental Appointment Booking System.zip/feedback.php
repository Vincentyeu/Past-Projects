<?php
session_start();
include 'header.php';
require_once 'db_connect.php';

// Check if user is logged in
if (!isset($_SESSION['customerid'])) {
    header('Location: login.php');
    exit();
}

// Get user_id from session
$userId = $_SESSION['customerid'];

// Fetch completed appointments
$sql = "SELECT appointment_id, dentist_id FROM booking WHERE user_id = '$userId' AND status = 'completed'";
$result = mysqli_query($conn, $sql);

// Generate new feedback ID
$feedbackResult = mysqli_query($conn, "SELECT feedback_id FROM feedback ORDER BY feedback_id DESC LIMIT 1");
$feedbackRow = mysqli_fetch_assoc($feedbackResult);
$lastFeedbackId = $feedbackRow ? $feedbackRow['feedback_id'] : 'F000';
$feedbackId = 'F' . str_pad(substr($lastFeedbackId, 1) + 1, 3, '0', STR_PAD_LEFT);
?>

<head>
<style>
    .rating {
        display: flex;
        flex-direction: row-reverse;
        justify-content: center;
        align-items: center;
    }

    .rating input {
        display: none;
    }

    .rating label {
        font-size: 2rem; /* Increased size for bigger stars */
        color: #ddd;
        cursor: pointer;
        transition: color 0.3s;
    }

    .rating label:hover,
    .rating input:checked ~ label {
        color: #ffcc00; /* Color of filled stars */
    }

    .rating label:before {
        content: '\2605'; /* Unicode character for star */
    }

    .rating input:checked + label:before {
        color: #ffcc00; /* Color of filled stars when checked */
    }

    /* Optional: Adjust star size and spacing */
    .rating label {
        font-size: 2rem; /* Size of the stars */
        margin: 0 0.1rem; /* Spacing between stars */
    }
</style>
</head>

<body>
<!-- Feedback Form Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="row g-5">
            <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                <h1 class="mb-4">Give Feedback About Your Appointment</h1>
                <p class="mb-4">We appreciate your feedback. Please rate your experience and provide any comments you have.</p>
            </div>
            <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="bg-light rounded p-5">
                    <?php if (mysqli_num_rows($result) > 0): ?>
<form action="submit_feedback.php" method="post">
    <input type="hidden" name="user_id" value="<?php echo $userId; ?>">
    <input type="hidden" name="feedback_id" value="<?php echo $feedbackId; ?>">
    <input type="hidden" id="dentist_id" name="dentist_id">
    <div class="mb-3">
        <label for="appointment_id" class="form-label">Select Appointment</label>
        <select class="form-select" id="appointment_id" name="appointment_id" required>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <option value="<?php echo $row['appointment_id']; ?>" data-dentist-id="<?php echo $row['dentist_id']; ?>">
                    Appointment ID: <?php echo $row['appointment_id']; ?>
                </option>
            <?php endwhile; ?>
        </select>
    </div>
    <div class="mb-3">
        <label for="user_rating" class="form-label">Rate Your Dentist</label>
        <div class="rating">
            <input type="radio" name="user_rating" value="5" id="5"><label for="5"></label>
            <input type="radio" name="user_rating" value="4" id="4"><label for="4"></label>
            <input type="radio" name="user_rating" value="3" id="3"><label for="3"></label>
            <input type="radio" name="user_rating" value="2" id="2"><label for="2"></label>
            <input type="radio" name="user_rating" value="1" id="1"><label for="1"></label>
        </div>
    </div>
    <div class="mb-3">
        <label for="user_comment" class="form-label">Comment</label>
        <textarea class="form-control" id="user_comment" name="user_comment" rows="3" required></textarea>
    </div>
    <div class="col-12">
        <button class="btn btn-primary w-100 py-3" type="submit">Submit Feedback</button>
    </div>
</form>
                    <?php else: ?>
                        <p class="text-center">You have no completed appointments to provide feedback for.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Feedback Form End -->

<script>
document.getElementById('appointment_id').addEventListener('change', function() {
    var selectedOption = this.options[this.selectedIndex];
    var dentistId = selectedOption.getAttribute('data-dentist-id');
    document.getElementById('dentist_id').value = dentistId;
});

// Trigger change event on page load to set the dentist_id value for the first appointment
document.getElementById('appointment_id').dispatchEvent(new Event('change'));
</script>

<?php
mysqli_close($conn);
?>

<?php
include 'footer.php'
?>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>