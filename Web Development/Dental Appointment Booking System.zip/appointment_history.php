<?php
session_start();
require_once 'db_connect.php';
include('header.php');

// Check if user is logged in
if (!isset($_SESSION['customerid'])) {
    header('Location: login.php');
    exit();
}

// Get user_id from session
$userId = $_SESSION['customerid'];

// Fetch user appointment history
$sql = "SELECT appointment_id, appointment_date, appointment_time, reason, status FROM booking WHERE user_id = '$userId' ORDER BY appointment_date DESC";
$result = mysqli_query($conn, $sql);

?>

<body>
	
<!-- Appointment History Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="row g-5">
            <div class="col-lg-12 wow fadeInUp" data-wow-delay="0.1s">
                <h1 class="mb-4 text-center">Your Appointment History</h1>
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <div class="bg-light rounded p-5">
                        <table class="table">
<thead>
    <tr>
        <th scope="col">Appointment ID</th>
        <th scope="col">Date</th>
        <th scope="col">Time</th>
        <th scope="col">Reason</th>
        <th scope="col">Status</th>
        <th scope="col">Action</th> <!-- New column for action buttons -->
    </tr>
</thead>
<tbody>
    <?php while ($row = mysqli_fetch_assoc($result)): ?>
        <tr>
            <td><?php echo $row['appointment_id']; ?></td>
            <td><?php echo date("F j, Y", strtotime($row['appointment_date'])); ?></td>
            <td><?php echo date("h:i A", strtotime($row['appointment_time'])); ?></td>
            <td><?php echo $row['reason']; ?></td>
            <td><?php echo ucfirst($row['status']); ?></td>
            <td>
                <?php if ($row['status'] == 'pending' || $row['status'] == 'accepted'): ?>
                    <form action="cancel_appointment.php" method="post">
                        <input type="hidden" name="appointment_id" value="<?php echo $row['appointment_id']; ?>">
                        <button type="submit" class="btn btn-danger btn-sm">Cancel</button>
                    </form>
                <?php endif; ?>
            </td>
        </tr>
    <?php endwhile; ?>
</tbody>

                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-center">You have no appointment history.</p>
                <?php endif; ?>
                <div class="text-center mt-4">
                    <a href="index.php" class="btn btn-primary">Back to Home</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Appointment History End -->

<?php
mysqli_close($conn);
?>

<?php
include 'footer.php'
?>
    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>