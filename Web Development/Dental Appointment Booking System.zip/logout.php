<?php
session_start();
session_destroy();
unset($_SESSION['customer']);
unset($_SESSION['customerid']);
header('location:login.php');// Redirect to login page

exit();
?>
