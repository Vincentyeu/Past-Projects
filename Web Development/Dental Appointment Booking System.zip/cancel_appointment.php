<?php
session_start();
require_once 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_SESSION['customerid'])) {
    $userId = $_SESSION['customerid'];
    $appointmentId = $_POST['appointment_id'];

    // Check if the appointment belongs to the logged-in user
    $checkSql = "SELECT * FROM booking WHERE appointment_id = '$appointmentId' AND user_id = '$userId'";
    $checkResult = mysqli_query($conn, $checkSql);

    if (mysqli_num_rows($checkResult) == 1) {
        $row = mysqli_fetch_assoc($checkResult);
        $status = $row['status'];

        // Only cancel if status is pending or accepted
        if ($status == 'pending' || $status == 'accepted') {
            // Update status to cancelled
            $updateSql = "UPDATE booking SET status = 'cancelled' WHERE appointment_id = '$appointmentId'";
            if (mysqli_query($conn, $updateSql)) {
                // Show JavaScript alert and redirect
                echo '<script>';
                echo 'alert("Appointment cancelled successfully.");';
                echo 'window.location.href = "appointment_history.php";'; // Redirect to history
                echo '</script>';
            } else {
                echo "Error cancelling appointment: " . mysqli_error($conn);
            }
        } else {
            echo "Appointment cannot be cancelled. Status is: " . $status;
        }
    } else {
        echo "Invalid appointment ID or you don't have permission to cancel this appointment.";
    }
} else {
    echo "Unauthorized access.";
}
mysqli_close($conn);
?>






