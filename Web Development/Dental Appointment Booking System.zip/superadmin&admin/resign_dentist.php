<?php
include 'db_connect.php';

if (isset($_GET['dentist_id'])) {
    $dentist_id = $_GET['dentist_id'];

    $sql = "DELETE FROM dentist WHERE dentist_id = '$dentist_id'";

    if ($conn->query($sql) === TRUE) {
        echo "Dentist deleted successfully.";
    } else {
        echo "Error deleting dentist: " . $conn->error;
    }

    $conn->close();
}

header("Location: manage_dentist.php");
exit();
?>
