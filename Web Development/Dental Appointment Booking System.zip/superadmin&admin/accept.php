<?php
include 'db_connect.php';

if (isset($_GET['appointment_id']) && isset($_GET['dentist_id'])) {
    $appointment_id = $_GET['appointment_id'];
    $dentist_id = $_GET['dentist_id'];

    // Sanitize inputs to prevent SQL injection
    $booking_id = mysqli_real_escape_string($conn, $appointment_id);
    $dentist_id = mysqli_real_escape_string($conn, $dentist_id);

    $sql = "UPDATE booking SET status='accepted', dentist_id='$dentist_id' WHERE appointment_id='$appointment_id'";

    if ($conn->query($sql) === TRUE) {
        echo "Appointment accepted by dentist with ID $dentist_id successfully.";
    } else {
        echo "Error: " . $conn->error;
    }

    $conn->close();

    // Redirect to the view appointments page
    header("Location: view_appointment.php");
    exit();
} else {
    echo "No booking ID or dentist ID provided.";
}
?>
