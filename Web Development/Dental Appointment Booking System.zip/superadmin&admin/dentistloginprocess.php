<?php
session_start();
require_once('db_connect.php');
if(isset($_POST) &!empty($_POST)){
	$id=filter_var($_POST['id']);
	$pass=$_POST['password'];
	$sql="SELECT* FROM dentist WHERE dentist_id='$id' ";
	$res=mysqli_query($conn,$sql) or die(mysqli_error($conn));
	$count=mysqli_num_rows($res);
	$row=mysqli_fetch_assoc($res);

if($count==1){	
	if($pass == $row['dentist_password']){
		$_SESSION['dentistid']=$row['dentist_id'];
		header('location:view_appointment.php');
	}else{

		header('location:dentistlogin.php?message=2');
	}
}else{
	header('location:dentistogin.php?message=1');
}
}
?>