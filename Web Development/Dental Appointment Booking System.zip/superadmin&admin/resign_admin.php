<?php
include 'db_connect.php';

if (isset($_GET['admin_id'])) {
    $admin_id = $_GET['admin_id'];

    $sql = "DELETE FROM admin WHERE admin_id = '$admin_id'";

    if ($conn->query($sql) === TRUE) {
        echo "Admin deleted successfully.";
    } else {
        echo "Error deleting admin: " . $conn->error;
    }

    $conn->close();
}

header("Location: manage_admin.php");
exit();
?>
