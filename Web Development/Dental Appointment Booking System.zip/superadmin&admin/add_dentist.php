<!DOCTYPE html>
<html>
<head>
    <title>Add Dentist</title>
    <link rel="stylesheet" href="sastyle.css">
</head>
<body>
    <div class="container">
        <div class="form-box">
            <a class="back-btn" href="manage_dentist.php">Back</a>
            <h2>Add New Dentist</h2>
            <form action="add_dentist.php" method="POST">
                ID: <input type="text" name="dentist_id" required><br>
                Name: <input type="text" name="dentist_name" required><br>
                Password: <input type="password" name="dentist_password" required><br>
                IC: <input type="text" name="dentist_ic" required><br>
                Contact No: <input type="text" name="dentist_contact_no" required><br>
                Age: <input type="text" name="age"><br>
                Gender: 
                <input type="radio" name="gender" value="Male" checked>Male
                <input type="radio" name="gender" value="Female">Female<br>
                Graduate University: <input type="text" name="graduate" required><br>
                Work Experience (Since): <input type="text" name="experience" required><br>
                <input type="submit" name="add_dentist" value="Add dentist">
            </form>

            <?php
            if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_dentist'])) {
                include 'db_connect.php';

                // Sanitize inputs to prevent SQL injection
                $dentist_id = mysqli_real_escape_string($conn, $_POST['dentist_id']);
                $dentist_name = mysqli_real_escape_string($conn, $_POST['dentist_name']);
                $dentist_password = mysqli_real_escape_string($conn, $_POST['dentist_password']);
                $dentist_ic = mysqli_real_escape_string($conn, $_POST['dentist_ic']);
                $dentist_contact_no = mysqli_real_escape_string($conn, $_POST['dentist_contact_no']);
                $age = mysqli_real_escape_string($conn, $_POST['age']);
                $gender = mysqli_real_escape_string($conn, $_POST['gender']);
                $graduate = mysqli_real_escape_string($conn, $_POST['graduate']);
                $experience = mysqli_real_escape_string($conn, $_POST['experience']);


                // Insert query
                $sql = "INSERT INTO dentist (dentist_id, dentist_name, dentist_password, dentist_ic, dentist_contact_no, age, gender, graduate, experience) 
                        VALUES ('$dentist_id', '$dentist_name', '$dentist_password', '$dentist_ic', '$dentist_contact_no', '$age', '$gender', '$graduate', '$experience')";

                if ($conn->query($sql) === TRUE) {
                    echo "New dentist added successfully";
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }

                $conn->close();
            }
            ?>
        </div>
    </div>
</body>
</html>
