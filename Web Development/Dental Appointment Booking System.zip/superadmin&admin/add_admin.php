<!DOCTYPE html>
<html>
<head>
    <title>Add Admin</title>
	<link rel="stylesheet" href="sastyle.css">
</head>
<body>
    <div class="container">
        <div class="form-box">
			<a class="back-btn" href="manage_admin.php">Back</a>
            <h2>Add New Admin</h2>
            <form action="add_admin.php" method="POST">
                Admin ID: <input type="text" name="admin_id" required><br>
                Admin Name: <input type="text" name="admin_name" required><br>
                Admin Password: <input type="text" name="admin_password" required><br>
                <input type="submit" name="add_admin" value="Add Admin">
            </form>

            <?php
            if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_admin'])) {
                include 'db_connect.php';

                $admin_id = $_POST['admin_id'];
                $admin_name = $_POST['admin_name'];
                $admin_password = $_POST['admin_password'];

                $sql = "INSERT INTO admin (admin_id, admin_name, admin_password) VALUES ('$admin_id', '$admin_name', '$admin_password')";

                if ($conn->query($sql) === TRUE) {
                    echo "New admin added successfully";
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }

                $conn->close();
            }
            ?>
        </div>
    </div>
</body>
</html>
