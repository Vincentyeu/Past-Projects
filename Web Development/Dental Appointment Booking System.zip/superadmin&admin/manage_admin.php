<!DOCTYPE html>
<html>
<head>
    <title>View Admins</title>
    <link rel="stylesheet" href="sastyle.css">

</head>
<body>
<?php include 'sanavi.php'; ?>
    <div class="container2">
        <div class="table-box">
		<h1>Hi, superadmin! This is the homepage :D</h1>
            <h2>Current Admins</h2>
            <table>
                <thead>
                    <tr>
                        <th>Admin ID</th>
                        <th>Admin Name</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    include 'db_connect.php';

                    $sql = "SELECT admin_id, admin_name FROM admin";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr><td>" . $row["admin_id"]. "</td><td>" . $row["admin_name"]. "</td>";
                            echo "<td><a class='delete-btn' href='resign_admin.php?admin_id=" . $row["admin_id"] . "' onclick='return confirm(\"Are you sure you want to delete this admin?\")'>Delete</a></td></tr>";
                        }
                    } else {
                        echo "<tr><td colspan='3'>No admins found</td></tr>";
                    }

                    $conn->close();
                    ?>
                </tbody>
            </table>
			<a class='add-btn' href='add_admin.php'>Add New Admin</a>
        </div>
    </div>
</body>
</html>
