<!DOCTYPE html>
<html>
<head>
    <title>View Admins</title>
    <link rel="stylesheet" href="sastyle.css">
    <script>
        function promptDentistId(appointmentId) {
            var dentistId = prompt("Please enter the Dentist ID:");
            if (dentistId != null && dentistId != "") {
                window.location.href = 'accept.php?appointment_id=' + appointmentId + '&dentist_id=' + dentistId;
            }
        }
    </script>
</head>
<body>
    <?php include 'anavi.php'; ?>
    <div class="container">
        <div class="table-box">
            <h1>Hi, admin/dentist! This is the homepage :D</h1>
            <h2>Current Pending Appointments</h2>
            <table>
                <thead>
                    <tr>
                        <th>Appointment_ID</th>
                        <th>Patient_ID</th>
                        <th>Treatment</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    include 'db_connect.php';

                    $sql = "SELECT appointment_id, user_id, reason, appointment_date, appointment_time FROM booking WHERE status='pending'";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row["appointment_id"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["user_id"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["reason"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["appointment_date"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["appointment_time"]) . "</td>";
                            echo "<td><a class='accept-btn' href='#' onclick='promptDentistId(\"" . $row["appointment_id"] . "\")'>Accept</a> ";
                            echo "<a class='decline-btn' href='decline.php?appointment_id=" .$row["appointment_id"] . "' onclick='return confirm(\"Are you sure you want to decline this appointment?\")'>Decline</a></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='6'>No pending appointments</td></tr>";
                    }

                    $conn->close();
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
