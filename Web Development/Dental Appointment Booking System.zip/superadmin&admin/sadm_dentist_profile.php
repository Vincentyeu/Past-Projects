<!DOCTYPE html>
<html>
<head>
    <title>Dentist Profile</title>
    <style>
body{
	background-image: url('bg.jpg')
}
.container1{
	max-width:900px;
    margin: 20px auto;
    padding: 20px;
    background-color: lightblue;
    border: 1px solid #ddd;
    border-radius: 8px;	
}
	
.container2 {
    max-width: 800px;
    margin: 20px auto;
    padding: 20px;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
}

.table-box {
    margin-top: 20px;
}

h2 {
    color: #333;
    font-size: 28px;
    margin-bottom: 15px;
    text-align: center;
}

table {
    width: 100%;
    border-collapse: collapse;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

table th, table td {
    border: 1px solid #ddd;
    padding: 12px;
    text-align: left;
	font-size:20px;
}

table th {
    background-color: #f5f5f5;
    color: #333;
    font-weight: bold;
    text-transform: uppercase;
}

table td {
    background-color: #fff;
}

table tr:nth-child(even) td {
    background-color: #f9f9f9;
}

table a {
    color: #007bff;
    text-decoration: none;
    transition: color 0.3s;
}

table a:hover {
    color: #0056b3;
    text-decoration: underline;
}

</style>
</head>
<body>
    <div class="container1">
		<a href="manage_dentist.php">Back</a>
            <?php
include 'db_connect.php';

echo '<div class="container2">';
echo '<div class="profile-box">';
echo '<h2>Dentist Profile</h2>';

if (isset($_GET['dentist_id'])) {
    $dentist_id = $_GET['dentist_id'];
    $sql = "SELECT * FROM dentist WHERE dentist_id = '$dentist_id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo '<table class="table-box">';
        echo '<tr><th>Attribute</th><th>Details</th></tr>';

        $row = $result->fetch_assoc();
        echo "<tr><td>ID</td><td>" . $row["dentist_id"] . "</td></tr>";
        echo "<tr><td>Name</td><td>" . $row["dentist_name"] . "</td></tr>";
		echo "<tr><td>IC</td><td>" . $row["dentist_ic"] . "</td></tr>";
        echo "<tr><td>Password</td><td>" . $row["dentist_password"] . "</td></tr>";
        echo "<tr><td>Contact No</td><td>" . $row["dentist_contact_no"] . "</td></tr>";
        echo "<tr><td>Graduate</td><td>" . $row["graduate"] . "</td></tr>";
        echo "<tr><td>Gender</td><td>" . $row["gender"] . "</td></tr>";
        echo "<tr><td>Age</td><td>" . $row["age"] . "</td></tr>";
        echo "<tr><td>Experience (Since)</td><td>" . $row["experience"] . "</td></tr>";
        echo "<tr><td>Rating</td><td>" . $row["rating"] . "</td></tr>";

        echo '</table>';
    } else {
        echo "<p>No dentist found with the provided ID.</p>";
    }
} else {
    echo "<p>No dentist ID provided.</p>";
}
echo '</div>'; 
echo '</div>'; 

$conn->close();
?>


    </div>
</body>
</html>
