<!DOCTYPE html>
<html>
<head>
    <title>Accepted Appointments</title>
    <link rel="stylesheet" href="sastyle.css">

</head>
<body>
<?php include 'anavi.php'; ?>
    <div class="container">
        <div class="form-box">
            <h2>View Accepted Appointments</h2>
            <form action="" method="GET">
			Choose the Dentist:
            <input type="text" name="dentist_id" placeholder="Dentist ID" required>
			<input type="submit" value="View Appointments">
			</form>
        </div>

        <?php
        include 'db_connect.php';

        // Check if dentist_id is provided in the query string
        if (isset($_GET['dentist_id'])) {
            $dentist_id = $_GET['dentist_id'];

            // SQL query to fetch appointments filtered by dentist_id and status = 'accepted'
            $sql = "SELECT appointment_id, user_id, reason, appointment_date, appointment_time 
                    FROM booking 
                    WHERE status = 'accepted' AND dentist_id = '$dentist_id'
					ORDER BY appointment_date ASC, appointment_time ASC";

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo "<div class='table-box'>
                        <h2>Accepted Appointments for Dentist ID: $dentist_id</h2>
                        <table>
                            <thead>
                                <tr>
                                    <th>Appointment ID</th>
                                    <th>Patient ID</th>
                                    <th>Treatment</th>
                                    <th>Date</th>
                                    <th>Time</th>
									<th>Action</th>
                                </tr>
                            </thead>
                            <tbody>";

                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["appointment_id"] . "</td>";
                    echo "<td>" . $row["user_id"] . "</td>";
                    echo "<td>" . $row["reason"] . "</td>";
                    echo "<td>" . $row["appointment_date"] . "</td>";
                    echo "<td>" . $row["appointment_time"] . "</td>";
					echo "<td><a class='complete-btn' href='complete.php?appointment_id=" . $row["appointment_id"] . "' onclick='return confirm(\"Are you sure this appointment has been completed\")'>Complete</a></td>";
                    echo "</tr>";
                }

                echo "</tbody></table></div>";
            } else {
                echo "<div class='table-box'>
                        <p>No accepted appointments found for Dentist ID: $dentist_id</p>
                      </div>";
            }

            $conn->close();
        }
        ?>
    </div>
</body>
</html>
