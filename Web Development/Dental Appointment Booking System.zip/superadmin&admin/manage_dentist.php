<!DOCTYPE html>
<html>
<head>
    <title>View Dentists</title>
    <style>
	<link rel="stylesheet" href="sastyle.css">
    </style>
</head>
<body>
<?php include 'sanavi.php'; ?>
    <div class="container2">
        <div class="table-box">
            <h2>Current Dentists</h2>
            <table>
                <thead>
                    <tr>
                        <th>Dentist ID</th>
                        <th>Dentist Name</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    include 'db_connect.php';

                    $sql = "SELECT dentist_id, dentist_name FROM dentist";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
						echo "<tr>";
						echo "<td><a href='sadm_dentist_profile.php?dentist_id=" . $row["dentist_id"]. "'>" . $row["dentist_id"]. "</a></td>";
						echo "<td>" . $row["dentist_name"] . "</td>";
						echo "<td><a class='delete-btn' href='resign_dentist.php?dentist_id=" . $row["dentist_id"] . "' onclick='return confirm(\"Are you sure you want to delete this dentist?\")'>Delete</a></td>";
						echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='3'>No dentist found</td></tr>";
                    }

                    $conn->close();
                    ?>
                </tbody>
            </table>
			<a class='add-btn' href='add_dentist.php'>Add New Dentist</a>
        </div>
    </div>
</body>
</html>
