<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="sastyle.css">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

</head>
<body>
<div class="navbar">
  <a href="manage_admin.php">
            <h2><i class="fa fa-address-card"></i> Superadmin</h2>
        </a>
  <a href="manage_admin.php"><h2>Admin Manage</h2></a>
  <a href="manage_dentist.php"><h2>Dentist Manage</h2></a> 
  <a href="report.php"><h2>Appointment Report</h2></a>
  <a href="../login.php" class="logout"><h2>Logout <i class="fa fa-sign-out"></i></h2></a>
	
  </div>
</body>
</html>
