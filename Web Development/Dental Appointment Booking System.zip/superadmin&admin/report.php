<!DOCTYPE html>
<html>
<head>
    <title>View Report</title>
    <link rel="stylesheet" href="sastyle.css">
</head>
<body>
    <?php include 'sanavi.php'; ?>
    <div class="container">
        <div class="form-box">
            <h2>Choose the status:</h2>
            <form action="" method="GET">
			<h3>Choose the Dentist:</h3>
				<select id="status" name="status" required>
				<option value="">Select a Status</option>
				<option value="pending">Pending</option>
				<option value="accepted">Accepted</option>
				<option value="declined">Decline</option>
				<option value="completed">Completed</option>
				</select><br>
			<input type="submit" value="View Appointments">
			</form>
        </div>
        <?php
        include 'db_connect.php';

        if (isset($_GET['status'])) {
            $status = $_GET['status'];

            $sql = "SELECT appointment_id, user_id, reason, appointment_date, appointment_time 
                    FROM booking 
                    WHERE status = '$status' 
					ORDER BY appointment_date ASC, appointment_time ASC";

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo "<div class='table-box'>
                        <h2>Appointments $status</h2>
                        <table>
                            <thead>
                                <tr>
                                    <th>Booking ID</th>
                                    <th>Patient ID</th>
                                    <th>Treatment</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                </tr>
                            </thead>
                            <tbody>";

                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["appointment_id"] . "</td>";
                    echo "<td>" . $row["user_id"] . "</td>";
                    echo "<td>" . $row["reason"] . "</td>";
                    echo "<td>" . $row["appointment_date"] . "</td>";
                    echo "<td>" . $row["appointment_time"] . "</td>";
                    echo "</tr>";
                }

                echo "</tbody></table></div>";
            } else {
                echo "<div class='table-box'>
                        <p>No $status appointement</p>
                      </div>";
            }

            $conn->close();
        }
        ?>
        </div>
</body>
</html>
