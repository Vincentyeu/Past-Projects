<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="superadmin&admin/sastyle.css">
<!-- Customized Bootstrap Stylesheet -->
<link href="css/bootstrap.min.css" rel="stylesheet">

<!-- Template Stylesheet -->
<link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="login-wrap">
	<div class="login-html">
		<input id="tab-1" type="radio" name="tab" class="sign-in" checked><label for="tab-1" class="tab">Admin Sign In</label>
		<input id="tab-2" type="radio" name="tab" class="sign-up"><label for="tab-2" class="tab"></label>
		<div class="login-form">
			<form class="sign-in-htm" method="post" action="adminloginproccess.php">

                <div>
					<?php 
							if(isset($_GET['message'])){ ?>
								<?php if($_GET['message']==2){ ?>
								<div class="alert alert-danger"><?php echo "Invalid name or password !"; ?></div>
								<?php } else { ?>

								<div class="alert alert-danger"><?php echo "Admin does not exist !"; ?></div>
								<?php } ?>
					<?php } ?>
				</div>

                <div class="group">
					<label for="admin" class="label">Admin ID</label>
					<input id="admin" name="id" type="text" class="input" required>
				</div>
				<div class="group">
					<label for="pass" class="label">Password</label>
					<input id="pass" name="password" type="password" class="input" data-type="password" required>
				</div> <!--
				<div class="group">
					<input id="check" type="checkbox" class="check" checked>
					<label for="check"><span class="icon"></span> Keep me Signed in</label>
				</div> -->
				<div class="group">
					<input type="submit" class="button" value="Sign In">
				</div>
				<div class="hr"></div>
				
			</form>
</body>            

<style>
    body{
	margin: 0;;
	/*color:#6a6f8c;
	background:#c8c8c8;
    background-image: url("../TSE_Dental Appointment Booking/img/header1.jpg");*/
    background-repeat:no-repeat;
    background-attachment: fixed;
    background-position: center;
    background-size:cover;
	font:0 16px/18px 'Open Sans',sans-serif;
}
/**/
*,:after,:before{box-sizing:border-box}
.clearfix:after,.clearfix:before{content:'';display:table}
.clearfix:after{clear:both;display:block}
a{color:inherit;text-decoration:none} 

.login-wrap{
	width:100%;
	margin: auto;
    margin-top: 50px;
	max-width:526px;
	min-height:570px;
	position:relative;
    /*background-image: url("../img/header1.jpg") center no-repeat;
	 background:url(https://raw.githubusercontent.com/khadkamhn/day-01-login-form/master/img/bg.jpg) no-repeat center; */
    background-color: skyblue;
    border-radius:25px;
	/*box-shadow:0 12px 15px 0 rgba(0,0,0,.24),0 17px 50px 0 rgba(0,0,0,.19); */
}

.login-html{
	width:100%;
	height:100%;
	position:absolute;
	padding: 50px 70px 50px 70px;
	/*background:rgba(40,57,101,.9);*/
}

.login-html .sign-in-htm,
.login-html .sign-up-htm{
	top:0;
	left:0;
	right:0;
	bottom:0;
	position:absolute;
	transform:rotateY(180deg);
	backface-visibility:hidden;
	transition:all .4s linear;
}
.login-html .sign-in,
.login-html .sign-up,
.login-form .group .check{
	display:none;
}
.login-html .tab,
.login-form .group .label,
.login-form .group .button{
	text-transform:uppercase;
    color:black;
	font-weight:bold;
	padding-bottom:5px;
}
.login-html .tab{
	font-size:30px;
	/*margin-right:15px;*/
	padding-bottom:50px;
    padding-left:70px;
    padding-left:70px;
	margin:auto;/*0 15px 10px 0 */
	display:inline-block;
	border-bottom:2px solid transparent;
}
.login-html .sign-in:checked + .tab,
.login-html .sign-up:checked + .tab{
	/*color:#fff;
    border-color:#1161ee; */
    color:black;
	
}
.login-form{
	min-height:345px;
	position:relative;
	perspective:1000px;
	transform-style:preserve-3d;
}
.login-form .group{
	margin-bottom:15px;
}
.login-form .group .label,
.login-form .group .input,
.login-form .group .button{
	width:100%;
	margin-bottom:2px;
	/*color:#fff;*/
	display:block;
}
.login-form .group .input{
    border:none;
	padding:15px 20px;
	border-radius:5px;
    color:black;
    background-color:Aliceblue;
	/*background:rgba(255,255,255,.1);*/
}
.login-form .group .button{
	border:none;
	padding:15px 20px;
	border-radius:5px;
    color:white;
   /* background-color:lightskyblue;
	background:rgba(255,255,255,.1);*/
}
.login-form .group input[type="password"]{
	text-security:circle;
	-webkit-text-security:circle;
}
.login-form .group .label{
	color:black;/*#aaa */
	font-size:12px;
}
.login-form .group .button{
	background:black;
	margin-top:80px;
}

.login-form .group .button:hover{
	background:#1161ee;
}

.login-html .sign-in:checked + .tab + .sign-up + .tab + .login-form .sign-in-htm{
	transform:rotate(0);
}
.login-html .sign-up:checked + .tab + .login-form .sign-up-htm{
	transform:rotate(0);
}

.hr{
	height:2px;
	margin:60px 0 50px 0;
	background:rgba(255,255,255,.2);
}

.foot-lnk{
	text-align:left;
	margin-top:0;
}

.foot-lnk a:link{
	color:grey;
}

.foot-lnk a:hover{
	color:deepskyblue;
}

.foot-lnk a:active{
	color:red;
}

</style>

</html>