<!DOCTYPE html>
<html>
<head>
    <title>View Dentists</title>
    <style>
	<link rel="stylesheet" href="sastyle.css">
    </style>
</head>
<body>
<?php include 'anavi.php'; ?>
    <div class="container2">
        <div class="table-box">
            <h2>Current Dentists</h2>
            <table>
                <thead>
                    <tr>
                        <th>Dentist ID</th>
                        <th>Dentist Name</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    include 'db_connect.php';

                    $sql = "SELECT dentist_id, dentist_name FROM dentist";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                           echo "<tr><td><a href='ad_dentist_profile.php?dentist_id=" . $row["dentist_id"]. "'>" . $row["dentist_id"]. "</a></td><td>" . $row["dentist_name"]. "</td></tr>";
                        }
                    } else {
                        echo "<tr><td colspan='2'>No dentist found</td></tr>";
                    }

                    $conn->close();
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
