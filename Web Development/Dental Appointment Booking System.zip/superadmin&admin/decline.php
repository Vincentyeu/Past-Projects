<?php
include 'db_connect.php';

if (isset($_GET['appointment_id'])) {
    $appointment_id = $_GET['appointment_id'];

    $sql = "UPDATE booking SET status='declined' WHERE appointment_id = '$appointment_id'";

    if ($conn->query($sql) === TRUE) {
        echo "Appointment declined successfully.";
    } else {
        echo "Error: " . $conn->error;
    }

    $conn->close();

    // Redirect to the view appointments page after query execution
    header("Location: view_appointment.php");
    exit();
} else {
    echo "No appointment ID provided.";
}
?>
