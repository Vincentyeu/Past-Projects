<?php
    session_start();
    include ('db_connect.php');
    
    if (!isset($_SESSION['customer'])) {
        header('location:login.php');
        exit;
    }

    
    $email = $_SESSION['customer'];
    $user_first_name = filter_var($_POST['user_first_name'], FILTER_SANITIZE_STRING);
    $user_last_name = filter_var($_POST['user_last_name'], FILTER_SANITIZE_STRING);
    $password = $_POST['password'];
    $user_ic = $_POST['user_ic'];
    $gender = $_POST['gender'];
    $age = $_POST['age'];
    $phone_no = $_POST['phone_no'];

    $sql = "UPDATE user_profile SET 
                user_first_name='$user_first_name', 
                user_last_name='$user_last_name', 
                user_password='$password',
                user_ic='$user_ic', 
                gender='$gender', 
                age='$age', 
                phone_no='$phone_no' 
            WHERE email='$email'";
    
    if (mysqli_query($conn, $sql)) {
        header('location:update_profile.php?message=success');
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }

    mysqli_close($conn);
?>
