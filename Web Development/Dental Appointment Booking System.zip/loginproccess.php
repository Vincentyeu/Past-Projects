<?php
session_start();
require_once('db_connect.php');
if(isset($_POST) &!empty($_POST)){
	$email=filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
	$pass=$_POST['password'];
	$sql="SELECT* FROM `user_profile` WHERE email='$email' ";
	$res=mysqli_query($conn,$sql) or die(mysqli_error($conn));
	$count=mysqli_num_rows($res);
	$row=mysqli_fetch_assoc($res);

if($email == "admin" && $pass == "adminlogin")
{
	header('location:superadmin&admin/adminlogin.php');
	exit;
} else if($email == "superadmin" && $pass == "superadminlogin")
{
	header('location:superadmin&admin/superadminlogin.php');
	exit;
}else if($email == "dentist" && $pass == "dentistlogin")
{
	header('location:superadmin&admin/dentistlogin.php');
	exit;
}

if($count==1){	
	if($pass == $row['user_password']){
		$_SESSION['customer']=$email;
		$_SESSION['customerid']=$row['user_id'];
		header('location:index.php');
	}else{

		header('location:login.php?message=2');
	}
}else{
	header('location:login.php?message=1');
}
}
?>